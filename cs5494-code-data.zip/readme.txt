CS5494 Assignment 1

Requirements
  Python 3.13.5, PyTorch 2.9.1, torchvision 0.24.1, matplotlib 3.10.0.
  The reported run used PyTorch/torchvision CUDA 12.8 builds on an RTX 5060
  Laptop GPU. A compatible GPU runtime is recommended. On Colab, select a
  GPU runtime and use the installed compatible PyTorch/torchvision pair.

Data
  The four original MNIST IDX files are included in data/MNIST/raw.
  torchvision can also download them if the raw files are absent.
  The report specifies all transformations, seeds and split sizes.

Reproduction
  Extract the ZIP and open a terminal in the extracted directory.
  Run these commands in order:

    python train.py all
    python analyze.py
    python plot_results.py

  An individual experiment can be run by replacing "all" with fvsbn, pixelcnn,
  pixelcnn_shallow, pixelcnn_narrow, pixelcnn_subset, gan, or gan_features.
  To check a CUDA installation with tiny data, run:
    python train.py all --smoke --output smoke
  For CPU training, use --device cpu. Runtime and numerical results may differ.

Results
  runs/<experiment>/metrics.json records the configuration, timing and final
  metrics. history.json stores per-epoch metrics. model.pt is the selected
  autoregressive checkpoint or the last GAN checkpoint. PNG files contain
  random samples or training-stage grids. runs/gan_probe.json contains the
  classifier-based coverage measurements. figures/ contains the report plots.

  The archive includes the original run outputs. Re-running the commands
  overwrites those output paths in your extracted copy.


